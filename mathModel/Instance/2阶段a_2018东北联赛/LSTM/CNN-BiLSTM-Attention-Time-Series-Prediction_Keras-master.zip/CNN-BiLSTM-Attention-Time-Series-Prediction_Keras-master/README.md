TensorFlow Version:1.9.0

Keras Version:2.0.2

My Blog: https://blog.csdn.net/qq_35649669/article/details/104793484

![layers](./Img/layers.PNG)
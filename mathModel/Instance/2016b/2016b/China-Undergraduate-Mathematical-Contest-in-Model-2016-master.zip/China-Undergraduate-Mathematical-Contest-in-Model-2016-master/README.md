# China-Undergraduate-Mathematical-Contest-in-Model-2016
2016年高教社杯全国大学生数学建模竞赛

# python-data-analysis
​	持续更新数据分析实例，包括但不限于数据清洗，统计检验，数据挖掘等内容，实现细节描述请参考博客~^▽^~~~
如果有帮助请给一个小星星呀(*^▽^*)

1. 练习1：https://blog.csdn.net/J358935/article/details/107272335
2. 练习2：https://blog.csdn.net/J358935/article/details/107825738
3. 练习3：https://blog.csdn.net/J358935/article/details/107827323
4. 练习4：https://blog.csdn.net/J358935/article/details/107855277
5. 练习5：https://blog.csdn.net/J358935/article/details/107930109
6. 练习6：https://blog.csdn.net/J358935/article/details/107975448
7. 

